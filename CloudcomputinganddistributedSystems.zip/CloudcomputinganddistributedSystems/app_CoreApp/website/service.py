import datetime
import json
import logging
import os
import time

###################################################################################
# MongoDB configuration
###################################################################################
import pymongo  # Import the PyMongo library

# MongoDB configuration
#Movies_MongoDb_ConfigURI = "mongodb://localhost:27017/"
Movies_MongoDb_ConfigURI = os.getenv('MOVIES_MONGODB_CONFIG_URI', "mongodb://localhost:27017/")
Movies_MongoDB_db = "test"
Movies_MongoDB_Collection = "TMDB_dataset"

# Connect to the MongoDB server
mongo_client = pymongo.MongoClient(Movies_MongoDb_ConfigURI)  # Connect to the MongoDB server
db = mongo_client[Movies_MongoDB_db]   # Connect to the sample_mflix database
movies = db[Movies_MongoDB_Collection]               # Connect to the movies collection  # Connect to the movies collection 

###################################################################################
# Redis configuration
###################################################################################
import redis

# Connect to the Redis server - Redis server must be running on port 7000 - not cluster
#redisDB = redis.Redis(host='127.0.0.1', port=7000, decode_responses=True)
redisDB = redis.Redis(host=os.getenv('MOVIES_REDIS_HOST','127.0.0.1'), port=os.getenv('MOVIES_REDIS_PORT',7000), decode_responses=True)


#define the default cache expiration time for the cache
DEFAULT_CACHE_EXPIRATION= 300 # 5 minutes

###################################################################################
# Neo4j configuration
###################################################################################
import neo4j
from neo4j import GraphDatabase

#URI = "neo4j://localhost"
URI = os.getenv('MOVIES_NEO4J_HOST', "neo4j://localhost")
AUTH = ("", "")

# Connect to the Neo4j server
while True:
    try:
        with GraphDatabase.driver(URI, auth=AUTH) as neo4j_driver:
            neo4j_driver.verify_connectivity()
            logging.info("Connected to Neo4j")
            break
    except Exception as e:
        logging.error(f"Connection failed: {e}. Retrying in 5 seconds...")
        time.sleep(5)

###################################################################################



def search_movie(text):
    """
    Search movies by title and sort results by popularity, text score and rating.
    Also return facets for field `genre`, `releaseYear` and `votes`.

    Hint: check MongoDB's $facet stage
    """
    
    search_result= movies.aggregate([
        { "$match": { "$text": { "$search": text } } },
        { "$sort": { "score": { "$meta": "textScore" }, "vote_average": -1 } },
        { "$facet": {
            "genreFacet": [
                { "$sortByCount": "$genres" }
            ],
            "releaseYearFacet": [
                { "$sortByCount": { "$year": "$release_date" }}
            ],
            "searchResults": [
                { "$project": { "_id": 1, "poster_path": 1, "release_date": 1, "score": { "$meta": "textScore" }, "title": 1, "vote_average": 1, "vote_count": 1 } }
            ],
            "votesFacet": [
                { "$sortByCount": { "$round": "$vote_average" }}
            ]
        } }        
    ])

    #return first search_result document
    for search_doc in search_result:

        return search_doc;

    #If query fails return empty
    return {}
    

def get_top_rated_movies():
    """
    Return top rated 25 movies with more than 5k votes
    
    """
    redis_key = "top_rated_movies"
    if redisDB.exists(redis_key):
        json_top_rated_movies= redisDB.get(redis_key)
        return json.loads(json_top_rated_movies)
    else:
        top_rated_movies = list(movies.aggregate([{ "$match": { "vote_count": { "$gt": 5000 } } }, { "$sort": { "vote_average": -1 } },
                            { "$limit": 25 },
                            { "$project": { "_id": 1, "poster_path": 1, "release_date": 1, "title": 1, "vote_average": 1, "vote_count": 1 } }])
                            )
        json_top_rated_movies = json.dumps(top_rated_movies, default=str)       
        redisDB.set(redis_key, json_top_rated_movies, ex=DEFAULT_CACHE_EXPIRATION)

        return top_rated_movies

def get_recent_released_movies():
    """
    Return recently released movies that at least are reviewed by 50 users
    """

    redis_key = "recent_released_movies"
    if redisDB.exists(redis_key):
        json_recent_released_movies= redisDB.get(redis_key)
        return json.loads(json_recent_released_movies)
    else:
        recent_released_movies= list(movies.aggregate([{ "$match": { "vote_count": { "$gt": 50 } } }, 
                             { "$sort": { "release_date": -1 } },
                                { "$limit": 25 },
                                { "$project": { "_id": 1, "poster_path": 1, "release_date": 1, "title": 1, "vote_average": 1, "vote_count": 1 } }
                            ]
                            )
                        )
        json_recent_released_movies = json.dumps(recent_released_movies, default=str)       
        redisDB.set(redis_key, json_recent_released_movies, ex=DEFAULT_CACHE_EXPIRATION)

        return recent_released_movies


def get_movie_details(movie_id):
    """
    Return detailed information for the specified movie_id
    """
    
    redis_key = "movie_details_" + str(movie_id)
    
    if redisDB.exists(redis_key):
        json_movie_details = redisDB.get(redis_key)
        redisDB.expire(redis_key, DEFAULT_CACHE_EXPIRATION) #Extend the expiration time
        return json.loads(json_movie_details)
    else:
        movie_details=movies.find_one({"_id": movie_id}, {"_id": 1, "genres": 1, "overview": 1,"poster_path":1, "release_date": 1, "tagline": 1, "title": 1, "vote_average": 1, "vote_count": 1})
        
        json_movie_details = json.dumps(movie_details, default=str)
    
        redisDB.set( redis_key, json_movie_details, ex=DEFAULT_CACHE_EXPIRATION)    

        return movie_details



def get_similar_movies(movie_id, genres):
    """
    Return a list of movies that are similar to the provided genres.

    Movies need to be sorted by the number genres that match in descending order
    (a movie matching two genres will appear before a movie only matching one). When
    several movies match with the same number of genres, movies with greater rating must
    appear first.

    Discard movies with votes by less than 500 users. Limit to 10 results.
    """
    return movies.aggregate([
            { "$match": { "genres": { "$in": genres }, "vote_count": { "$gt": 500 }, "_id": {"$ne":movie_id }}},
            { "$project": { "_id": 1, "genres": 1, "poster_path": 1, "release_date": 1, "title": 1, "vote_average": 1, "vote_count": 1 } },
            { "$unwind": "$genres" },
            { "$group": { 
                "_id": "$_id", 
                "genresCount": { "$sum": 1 }, 
                "poster_path": { "$first": "$poster_path" }, 
                "release_date": { "$first": "$release_date" }, 
                "title": { "$first": "$title" }, 
                "vote_average": { "$first": "$vote_average" }, 
                "vote_count": { "$first": "$vote_count" } 
            }},
            { "$sort": { "genresCount": -1, "vote_average": -1 } },
            { "$limit": 10 }
        ])


def get_movie_likes(username, movie_id):
    """
    Returns a list of usernames of users who also like the specified movie_id
    """
    
    s2name_list= (neo4j_driver.session().run('''
        match((s1:Student {name: $username}))
        match(m:Movie{id:$movie_id})-[:IS_FAVOURITE]-(s2:Student) 
        WHERE s2<>s1
        return s2.name
    ''', username=username, movie_id=movie_id))
  
    #extract the usernames from the result
    username_list = []
    for s2name in s2name_list:
        username_list.append(s2name["s2.name"])
    return username_list

def get_recommendations_for_me(username):
    """
    Return up to 10 movies based on similar users taste.
    """

    #We first get the top 5 students with the most movies in common with the user, then we get the top 10 movies liked by those students
    recomended_movies_ids=neo4j_driver.session().run('''
        match(s1:Student {name: $username})-[:IS_FAVOURITE]-(m:Movie)-[:IS_FAVOURITE]-(s2:Student)
        WITH s2, count(m) as movies
        ORDER BY movies DESC LIMIT 5
        //return s2
        match(s1:Student {name: $username})
        match(s2)-[fab:IS_FAVOURITE]-(m_s2:Movie)
        //RETURN s2,m_s2
        WHERE NOT (s1)-[:IS_FAVOURITE]-(m_s2)
        //return s2,m_s2
        WITH m_s2, count(fab) AS Stars
        ORDER BY Stars DESC LIMIT 10
        RETURN m_s2.id
    ''', username=username)

    #extract the movie list with details from the returned move_ids
    #We extract all the details of the movie using get_nivue_details to take advantage of the cache
    #Result will contain all the movie details instead of only the necessary for the recommendation, but it will be faster
    recomended_movies = []
    for movie in recomended_movies_ids:
        movie_details = get_movie_details(movie["m_s2.id"])
        recomended_movies.append(movie_details);
    return recomended_movies


    
