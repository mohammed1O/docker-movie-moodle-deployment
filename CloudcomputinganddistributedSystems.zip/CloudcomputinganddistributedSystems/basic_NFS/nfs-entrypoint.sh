#!/bin/sh
rpcbind || exit 1
rpc.statd || exit 1
rpc.nfsd || exit 1
exportfs -r
exec rpc.mountd -N 4 -F
